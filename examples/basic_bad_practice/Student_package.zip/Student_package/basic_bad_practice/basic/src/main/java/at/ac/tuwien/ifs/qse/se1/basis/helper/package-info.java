/**
 * This Package contains various helper classes like a class containing 
 * application-wide constants.
 * At the moment it contains two classes, one for helpfull mehtods, one containing 
 * constants.
 * 
 * @author The SE-Team
 * @version 1.0
 */
package at.ac.tuwien.ifs.qse.se1.basis.helper;