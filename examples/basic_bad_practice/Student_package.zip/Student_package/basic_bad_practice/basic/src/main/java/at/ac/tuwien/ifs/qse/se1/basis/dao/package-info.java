/**
 * The DAO Package contains all the <i>Data Access Objects</i>.
 * DAOs provide access to the persistence mechanism.
 * @author The SE-Team
 * @version 1.0
 * @see <a href="http://www.springframework.org/documentation"
 *   target="newWindow">Springframework-website</a>
 */
package at.ac.tuwien.ifs.qse.se1.basis.dao;