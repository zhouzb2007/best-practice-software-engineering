/**
 * Unit Tests for DAOs.
 * 
 * At the moment we are using only one implementation of the JDBC-DAO,
 * therefore we have only one TestClass for now.
 * 
 * @author The SE-Team
 * @version 1.0
 */
package basis.test.dao;