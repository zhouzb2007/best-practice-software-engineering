/**
 * This package contains the DAO's (Data Access 
 * Object) and their corresponding interfaces.<br>
 * 
 * @author Kristof
 * @version 0.1.0
 */
package ${groupId}.dao;