package ${groupId};

import org.apache.log4j.Logger;

import ${groupId}.gui.MainFrame;

/**
 * This class starts the User-Interface.
 * 
 * @author Kristof
 * @version 0.1.0
 * 
 */
public class Main {

	/**
	 * Retrieve log4j Logger for this class.
	 */
	private static Logger logger = Logger.getLogger(Main.class);

	/**
	 * Entry point for the application that starts the MainFrame.
	 * 
	 * @param args
	 * @see MainFrame
	 */
	public static void main(String[] args) {
		logger.info("Appliction started.");

		MainFrame main = new MainFrame();
		main.pack();
		main.setVisible(true);

		logger.info("Terminated Start Class");
	}
}
