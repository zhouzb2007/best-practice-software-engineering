package ${groupId}.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.object.MappingSqlQuery;
import org.springframework.transaction.PlatformTransactionManager;

import ${groupId}.bo.Student;

/**
 * Implementation of the Student Data Access Object for JDBC. This class makes
 * heavy use of the Spring Framework's facilities and provides access to the
 * data stored in the database aswell as defines how this data is mapped from
 * the application objects to the database tables.<br>
 * Also see the Bean-Config file ({@value ${groupId}.Constants#SPRINGBEANS})
 * for configuration.
 * 
 * @author Kristof
 * @version 0.1.0
 * 
 */
public class JDBCStudentDAO implements IStudentDAO {

	/**
	 * Retrieve log4j Logger for this class.
	 */
	private static Logger logger = Logger.getLogger(JDBCStudentDAO.class);

	/**
	 * SQL Datasource. In order to work with data from a database, we need to
	 * obtain a connection to the database. A Datasource is part of the JDBC
	 * specification and can be seen as a generalized connection factory.
	 */
	private DataSource dataSource = null;

	/**
	 * Transaction Manager. For encapsulating insert and updates in transaction.
	 */
	private PlatformTransactionManager transactionManager = null;

	/**
	 * SQL Query Strings
	 */
	private String sql_getStudents = "";

	/**
	 * Query Objects.
	 */
	private Query_GetStudents query_getStudents;

	/** ******************************************************************* */
	/** ******************************************************************* */
	/* INNER CLASSES TO DEFINE SQL STATEMENTS AND MAPPINGS */
	/** ******************************************************************* */
	/** ******************************************************************* */

	/**
	 * Defines the base class used for all other queries. This is a private
	 * inner class, as this is used only in this data access object
	 */
	private class BaseStudentQuery extends MappingSqlQuery {

		public BaseStudentQuery(DataSource ds, String sql) {
			super(ds, sql);
		}

		protected Student mapRow(ResultSet rs, int rowNumber)
				throws SQLException {

			Student student = new Student();
			student.setMatrikelnummer(rs.getString("matrikelnummer"));
			return student;
		}
	}

	/**
	 * Defines the class used for to get all Students from the database. This is
	 * a private inner class, as this is used only in this data access object
	 */
	private class Query_GetStudents extends BaseStudentQuery {

		public Query_GetStudents(DataSource ds) {
			super(ds, sql_getStudents);
			compile();
		}
	}

	/** ******************************************************************* */
	/** ******************************************************************* */
	/* C O N S T R U C T O R */
	/** ******************************************************************* */
	/** ******************************************************************* */

	JDBCStudentDAO() {
		super();
	}

	/**
	 * The Initialise Method must be called after all bean values are set,
	 * particularly the datasource and the transaction manager. This is actually
	 * performed by the Spring Framework, which sets first of all, all Java Bean
	 * Properties and eventually calls this init method (see bean definition in
	 * beans.xml configuration file)
	 */
	public void init() {
		logger.debug("Initialize StudentDAO");
		query_getStudents = new Query_GetStudents(dataSource);
	}

	/**
	 * The Destroy Method is called by the Spring Framework to end the lifecycle
	 * of this bean, but <b>only</b> when the bean is created as singleton.
	 * Check the bean definition in beans.xml configuration file for details.
	 */
	public void destroy() {
		logger.debug("Destruction of: " + this.getClass());
	}

	/** ******************************************************************* */
	/*
	 * BEAN SETTERS FOR DEPENDENCY INJECTION
	 * 
	 * Dependency Injection is a design pattern in which the responsibility for
	 * object creation and object linking is removed from the objects themselves
	 * and transferred to a factory object. It is a way to achieve loose
	 * coupling between objects and results in highly testable objects
	 * (controlled unit tests).
	 * 
	 * Factory Object: (Design Pattern) is an object for creating other objects.
	 * Typically a factory has a method for every kind of object it is capable
	 * of creating. these methods optionally accept parameters defining how the
	 * object is created and then return the created object.
	 */
	/** ******************************************************************* */
	/** ******************************************************************* */

	/**
	 * Sets the SQL String to retrieve the students from the database
	 * 
	 * @param sql_getStudents
	 *            SQL Statement as String
	 */
	public void setSql_getStudents(String sql_getStudents) {
		this.sql_getStudents = sql_getStudents;
	}

	/**
	 * Sets the Datasource to connect to database.
	 * 
	 * @param dataSource
	 *            SQL Datasource
	 * @see #dataSource
	 */
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	/**
	 * Sets the transaction manager.
	 * 
	 * @param transactionManager
	 *            central interface in Spring's transaction infrastructure
	 * @see #transactionManager
	 */
	public void setTransactionManager(
			PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

	/** ******************************************************************* */
	/*
	 * DAO METHODS
	 * 
	 * A Data Access Object (DAO) is a component which provides a common
	 * interface between the application and one or more data storage devices,
	 * such as a database or a file. The advantage of using data access objects
	 * is that any business object (which contains application or operation
	 * specific details) does not require direct knowledge of the final
	 * destination for the information it manipulates. As a result, _if_ it is
	 * necessary to change where or how the data is stored, these modifications
	 * can be made without needing to change the main application.
	 */
	/** ******************************************************************* */
	/** ******************************************************************* */

	/**
	 * Retrieves all students from the database. <br>
	 * <b>Warning:</b> this type of DAO method would not be used in a real-
	 * world application because there may be thousands of students in the
	 * database and this method would retrieve them all. <br>
	 * This is usually not needed: it will generate a huge load on the database
	 * and also require enormous amounts of memory. Morover, there is hardly an
	 * application conceivable that needs more than a few dozen datasets at any
	 * one time.
	 */
	@SuppressWarnings("unchecked")
	public List<Student> getStudents() throws Exception {

		List<Student> students = null;
		students = query_getStudents.execute();
		if (students.size() > 0) {
			logger.debug("Retrieved " + students.size() + " students");
			return students;
		} else {
			logger.debug("No student data available.");
			return null;
		}
	}

}