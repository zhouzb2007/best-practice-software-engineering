package ${groupId}.bo;

/**
 * POJO (Plain Old Java Object) Representing the internal state of an Object in
 * this example a Student object. This Class encapsulates all Datafields and
 * Methods needed for this Object.
 * 
 * @author Kristof
 * @version 0.1.0
 * 
 */
public class Student {

	/**
	 * Just one attribute to show the structure of a POJO.
	 */
	private String matrikelnummer;

	/**
	 * Method to get the private variable matrikelnummer of the POJO.
	 * 
	 * @return matrikelnummer
	 */
	public String getMatrikelnummer() {
		return matrikelnummer;
	}

	/**
	 * Method to set the private variable matrikelnummer of the POJO.
	 * 
	 * @param matrikelnummer
	 */
	public void setMatrikelnummer(String matrikelnummer) {
		this.matrikelnummer = matrikelnummer;
	}
}
