/**
 * This package contains all business objects for the 
 * application logic represented by POJO's (Plain Old 
 * Java Object).<br> 
 *
 * @author Kristof
 * @version 0.1.0
 */
package ${groupId}.bo;