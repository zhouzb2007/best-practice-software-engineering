/**
 * Javadoc information for this package
 *
 *
 */
package ${groupId}.dao.test;