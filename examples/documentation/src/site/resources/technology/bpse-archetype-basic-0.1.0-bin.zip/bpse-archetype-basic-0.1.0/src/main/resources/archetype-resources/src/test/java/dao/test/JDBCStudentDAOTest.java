package ${groupId}.dao.test;

import java.util.List;

import junit.framework.TestCase;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import ${groupId}.Constants;
import ${groupId}.bo.Student;
import ${groupId}.dao.IStudentDAO;

public class JDBCStudentDAOTest extends TestCase {

	private IStudentDAO studentDAO;

	private XmlBeanFactory xbf;

	private Logger logger = Logger.getLogger(JDBCStudentDAOTest.class);

	protected void setUp() throws Exception {
		super.setUp();
		ClassPathResource res = new ClassPathResource(Constants.SPRINGBEANS);
		xbf = new XmlBeanFactory(res);
		studentDAO = (IStudentDAO) xbf.getBean("StudentDAO");
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		studentDAO = null;
		xbf.destroySingletons();
	}

	public void testBeanInit() {
		logger.debug("Testing bean initialization");
		Student student = (Student) xbf.getBean("StudentKristofMeixner");
		assertNotNull(student);
		assertEquals("9725208", student.getMatrikelnummer());
	}

	public void testGetStudent() {
		logger.debug("Test of method getStudent");
		Student student = (Student) xbf.getBean("StudentMaxMustermann");
		Student student1 = (Student) xbf.getBean("StudentMimiMustermann");
		List<Student> dbstudents = null;
		try {
			dbstudents = studentDAO.getStudents();
		} catch (Exception e) {
			fail("Exception should not have been thrown.");
			e.printStackTrace();
		}
		assertNotNull(dbstudents);
		assertEquals(student.getMatrikelnummer(), dbstudents.get(0)
				.getMatrikelnummer());
		assertEquals(student1.getMatrikelnummer(), dbstudents.get(
				dbstudents.size() - 1).getMatrikelnummer());
	}
}
