package ${groupId}.dao;

import java.util.List;

import ${groupId}.bo.Student;

/**
 * Interface definition for the DAO (Data Access Object) that uses and
 * manipulates the POJO.
 * 
 * @author Kristof
 * @version 0.1.0
 * 
 */
public interface IStudentDAO {

	/**
	 * Interface method to fetch the Objects thus Students as a List from the
	 * underlying database.
	 * 
	 * @return List of Students
	 * @see Student
	 */
	public List<Student> getStudents() throws Exception;
}
