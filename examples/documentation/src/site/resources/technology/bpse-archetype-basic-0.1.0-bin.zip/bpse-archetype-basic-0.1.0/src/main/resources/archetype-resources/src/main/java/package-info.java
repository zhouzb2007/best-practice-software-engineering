/**
 * This package is the root package of archetype example.<br>
 * It contains the Start class to start the User-Interface 
 * and the class that contains all constants needed.
 *
 * @author Kristof
 * @version 0.1.0
 */
package ${groupId};