package ${groupId};

/**
 * This class contains all constants needed for the application.
 * 
 * @author Kristof
 * @version 0.1.0
 * 
 */
public class Constants {

	/**
	 * This constant defines the Spring configuration file.
	 */
	public final static String SPRINGBEANS = "beans.xml";
}
