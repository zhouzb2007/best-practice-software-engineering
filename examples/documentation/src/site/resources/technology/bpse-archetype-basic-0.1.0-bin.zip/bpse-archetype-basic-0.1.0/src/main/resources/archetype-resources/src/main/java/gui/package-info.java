/**
 * This package contains the class that provides the
 * User-Interface of the application and additional
 * components.<br>
 *
 * @author Kristof
 * @version 0.1.0
 */
package ${groupId}.gui;